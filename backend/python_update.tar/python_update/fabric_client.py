from hfc.fabric import Client
from hfc.fabric_ca import ca_service
import logging
import json
import hashlib
import uuid
from datetime import datetime

class FabricClient:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.client = Client(net_profile="path/to/connection-profile.yaml")
        self.channel_name = "mychannel"
        self.chaincode_name = "mychaincode"
        self.org_name = "Org1MSP"
        self.user = self.setup_user()
        self.channel = self.client.get_channel(self.channel_name)
        self.contract = self.channel.get_contract(self.chaincode_name)

    def setup_user(self):
        try:
            # Initialize CA client
            ca_client = ca_service.CAService(
                target="localhost:7054",
                ca_cert_path="path/to/ca-cert.pem"
            )
            
            # Enroll admin user
            admin_enrollment = ca_client.enroll("admin", "adminpw")
            
            # Register and enroll application user
            registration = ca_client.register(
                admin_enrollment, 
                "appuser", 
                "password"
            )
            
            user_enrollment = ca_client.enroll("appuser", "password")
            return user_enrollment
        except Exception as e:
            self.logger.error(f"Failed to setup user: {str(e)}")
            raise

    def add_block(self, data_dict):
        try:
            response = self.contract.submit(
                "addGeneralBlock", 
                args=[json.dumps(data_dict)],
                requestor=self.user
            )
            self.logger.info(f"Block added to Fabric ledger: {response}")
            return json.loads(response)
        except Exception as e:
            self.logger.error(f"Failed to add block: {str(e)}")
            return None

    def create_session_block(self, user_email, signup_method, device_id, action):
        try:
            self.logger.info(f"Creating session block for {user_email}")
            response = self.contract.submit(
                "addSessionBlock",
                args=[user_email, signup_method, device_id, action],
                requestor=self.user
            )
            session_id = response.decode('utf-8')
            self.logger.info(f"Session block created with session_id: {session_id}")
            return {"session_id": session_id, "_id": session_id}
        except Exception as e:
            self.logger.error(f"Failed to create session block: {str(e)}")
            return False

    def get_session_block(self, session_id):
        try:
            response = self.contract.evaluate(
                "getSessionBlockBySessionID", 
                args=[session_id],
                requestor=self.user
            )
            return json.loads(response.decode('utf-8'))
        except Exception as e:
            self.logger.error(f"Failed to get session block: {str(e)}")
            return None

    def validate_session_chain(self):
        try:
            response = self.contract.evaluate(
                "validateSessionChain",
                requestor=self.user
            )
            return json.loads(response.decode('utf-8'))
        except Exception as e:
            self.logger.error(f"Session chain validation failed: {str(e)}")
            return {"isValid": False, "error": str(e)}

    def get_active_sessions(self):
        try:
            response = self.contract.evaluate(
                "getActiveSessions",
                requestor=self.user
            )
            return json.loads(response.decode('utf-8'))
        except Exception as e:
            self.logger.error(f"Failed to get active sessions: {str(e)}")
            return []