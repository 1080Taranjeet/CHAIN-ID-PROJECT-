'use strict';

const { Contract } = require('fabric-contract-api');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

class AuthChaincode extends Contract {

    // Initialize the chaincode
    async initLedger(ctx) {
        console.info('============= START : Initialize Ledger ===========');
        await ctx.stub.putState('general_block_max_index', Buffer.from('0'));
        await ctx.stub.putState('session_block_max_index', Buffer.from('0'));
        console.info('============= END : Initialize Ledger ===========');
    }

    // Add a new general block
    async addGeneralBlock(ctx, dataJSON) {
        console.info('============= START : Add General Block ===========');

        // Parse and validate input
        let data;
        try {
            data = JSON.parse(dataJSON);
        } catch (error) {
            throw new Error('Invalid data JSON');
        }

        // Get current max index
        let maxIndex = 0;
        const maxIndexBuffer = await ctx.stub.getState('general_block_max_index');
        if (maxIndexBuffer && maxIndexBuffer.length > 0) {
            maxIndex = parseInt(maxIndexBuffer.toString());
        }
        const newIndex = maxIndex + 1;

        // Get previous block hash
        let previousHash = '0';
        if (maxIndex > 0) {
            const previousBlockBuffer = await ctx.stub.getState(`general_block:${maxIndex}`);
            if (!previousBlockBuffer || previousBlockBuffer.length === 0) {
                throw new Error('Failed to get previous block');
            }
            const previousBlock = JSON.parse(previousBlockBuffer.toString());
            previousHash = previousBlock.hash;
        }

        // Create new block
        const timestamp = new Date().toISOString();
        const hash = this.calculateGeneralBlockHash(newIndex, timestamp, dataJSON, previousHash);
        
        const newBlock = {
            index: newIndex,
            timestamp: timestamp,
            data: data,
            previous_hash: previousHash,
            hash: hash
        };

        // Store block
        await ctx.stub.putState(`general_block:${newIndex}`, Buffer.from(JSON.stringify(newBlock)));
        
        // Update max index
        await ctx.stub.putState('general_block_max_index', Buffer.from(newIndex.toString()));

        console.info('============= END : Add General Block ===========');
        return JSON.stringify(newBlock);
    }

    // Calculate hash for general block
    calculateGeneralBlockHash(index, timestamp, data, previousHash) {
        const blockString = JSON.stringify({
            index: index,
            timestamp: timestamp,
            data: data,
            previous_hash: previousHash
        });
        return crypto.createHash('sha256').update(blockString).digest('hex');
    }

    // Add a new session block
    async addSessionBlock(ctx, userEmail, signupMethod, deviceID, action) {
        console.info('============= START : Add Session Block ===========');

        // Get current max index
        let maxIndex = 0;
        const maxIndexBuffer = await ctx.stub.getState('session_block_max_index');
        if (maxIndexBuffer && maxIndexBuffer.length > 0) {
            maxIndex = parseInt(maxIndexBuffer.toString());
        }
        const newIndex = maxIndex + 1;

        // Get previous block hash
        let previousHash = '0';
        if (maxIndex > 0) {
            const previousBlockBuffer = await ctx.stub.getState(`session_block:${maxIndex}`);
            if (!previousBlockBuffer || previousBlockBuffer.length === 0) {
                throw new Error('Failed to get previous block');
            }
            const previousBlock = JSON.parse(previousBlockBuffer.toString());
            previousHash = previousBlock.current_hash;
        }

        // Create new block
        const timestamp = new Date().toISOString();
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days
        const deviceIDHash = crypto.createHash('sha256').update(deviceID).digest('hex');
        const nonce = 0; // Simplified for this example
        const currentHash = this.calculateSessionBlockHash(
            newIndex, userEmail, signupMethod, deviceIDHash, 
            action, timestamp, expiresAt, previousHash, nonce
        );

        const sessionID = uuidv4();
        const newBlock = {
            docType: 'session_block',
            block_index: newIndex,
            session_id: sessionID,
            user_email: userEmail,
            signup_method: signupMethod,
            device_id: deviceIDHash,
            action: action,
            timestamp: timestamp,
            expires_at: expiresAt,
            previous_hash: previousHash,
            nonce: nonce,
            current_hash: currentHash
        };

        // Store block
        await ctx.stub.putState(`session_block:${newIndex}`, Buffer.from(JSON.stringify(newBlock)));
        await ctx.stub.putState(`session_block_id:${sessionID}`, Buffer.from(JSON.stringify(newBlock)));

        // Update max index
        await ctx.stub.putState('session_block_max_index', Buffer.from(newIndex.toString()));

        console.info('============= END : Add Session Block ===========');
        return sessionID;
    }

    // Calculate hash for session block
    calculateSessionBlockHash(blockIndex, userEmail, signupMethod, deviceID, action, timestamp, expiresAt, previousHash, nonce) {
        const blockString = `${blockIndex}${userEmail}${signupMethod}${deviceID}${action}${timestamp}${expiresAt}${previousHash}${nonce}`;
        return crypto.createHash('sha256').update(blockString).digest('hex');
    }

    // Get session block by session ID
    async getSessionBlockBySessionID(ctx, sessionID) {
        const blockBuffer = await ctx.stub.getState(`session_block_id:${sessionID}`);
        if (!blockBuffer || blockBuffer.length === 0) {
            throw new Error(`Session ${sessionID} does not exist`);
        }
        return blockBuffer.toString();
    }

    // Validate session blockchain
    async validateSessionChain(ctx) {
        const maxIndexBuffer = await ctx.stub.getState('session_block_max_index');
        if (!maxIndexBuffer || maxIndexBuffer.length === 0) {
            return JSON.stringify({ isValid: false, error: 'No blocks in chain' });
        }

        const maxIndex = parseInt(maxIndexBuffer.toString());
        const chain = [];

        // Retrieve all blocks
        for (let i = 1; i <= maxIndex; i++) {
            const blockBuffer = await ctx.stub.getState(`session_block:${i}`);
            if (!blockBuffer || blockBuffer.length === 0) {
                return JSON.stringify({ isValid: false, error: `Missing block at index ${i}` });
            }
            chain.push(JSON.parse(blockBuffer.toString()));
        }

        // Validate chain
        for (let i = 1; i < chain.length; i++) {
            const current = chain[i];
            const previous = chain[i - 1];

            // Check previous hash
            if (current.previous_hash !== previous.current_hash) {
                return JSON.stringify({ 
                    isValid: false, 
                    error: `Chain broken at index ${current.block_index}`
                });
            }

            // Recalculate hash
            const computedHash = this.calculateSessionBlockHash(
                current.block_index,
                current.user_email,
                current.signup_method,
                current.device_id,
                current.action,
                current.timestamp,
                current.expires_at,
                current.previous_hash,
                current.nonce
            );

            if (computedHash !== current.current_hash) {
                return JSON.stringify({ 
                    isValid: false, 
                    error: `Hash mismatch at index ${current.block_index}`
                });
            }
        }

        return JSON.stringify({ isValid: true, error: null });
    }

    // Get active sessions
    async getActiveSessions(ctx) {
        const now = new Date().toISOString();
        const query = {
            selector: {
                docType: 'session_block',
                action: 'login',
                expires_at: { $gt: now }
            }
        };

        const iterator = await ctx.stub.getQueryResult(JSON.stringify(query));
        const results = [];
        let res = await iterator.next();

        while (!res.done) {
            if (res.value && res.value.value) {
                const strValue = Buffer.from(res.value.value.toString()).toString('utf8');
                try {
                    const record = JSON.parse(strValue);
                    results.push(record);
                } catch (err) {
                    console.log(err);
                }
            }
            res = await iterator.next();
        }
        await iterator.close();

        return JSON.stringify(results);
    }
}

module.exports = AuthChaincode;